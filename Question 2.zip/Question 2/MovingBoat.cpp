// C program to draw the moving boat
// using c graphics

#include <conio.h>
#include <dos.h>
#include <graphics.h>
#include <stdio.h>

// Driver Code
int main()
{
    // Initialize graphic driver
    int gdriver = DETECT, gmode, err;
    int i = 0, j, x, y, x1, y1, x2, y2;

    // Start graphics mode by passing
    // three arguments to initgraph()

    // &gdriver is the address of the
    // gdriver variable.

    // &gmode is the address of gmode

    // "C:Turboc3BGI" is the directory
    // path where BGI files are stored
    initgraph(&gdriver, &gmode,
            "C:\\Program Files (x86)\\Dev-Cpp");
    err = graphresult();

    if (err != grOk) {
        printf("Graphics Error: %s\n",
            grapherrormsg(err));

        return 0;
    }

    j = 0;

    // Initialize position for boat
    x = 50, y = getmaxy() / 2 + 140;

    while (x + 60 < getmaxx()
        && (!kbhit())) {

        // Set the positions for rain
        x1 = 10, i = y1 = 0;
        x2 = 0, y2 = 50;

        // Clears graphic screen
        cleardevice();

        // Set the color of river/sea
        setcolor(LIGHTBLUE);
        setlinestyle(SOLID_LINE, 1, 1);
        setfillstyle(SOLID_FILL,
                    LIGHTBLUE);

        // Draw the river/sea
        rectangle(0, getmaxy() / 2 + 150,
                getmaxx(), getmaxy());
        floodfill(getmaxx() - 10,
                getmaxy() - 10,
                LIGHTBLUE);

        // Rain drops
        setlinestyle(DASHED_LINE, 1, 2);

        while (i < 700) {
            line(x1, y1, x2, y2);
            x1 = x1 + 20;
            y2 = y2 + 50;
            i++;
        }

        // Drawing the boat
        setlinestyle(SOLID_LINE, 1, 2);
        setcolor(BROWN);

        setfillstyle(SOLID_FILL, BROWN);
        sector(x, y, 180, 360, 50, 10);

        setcolor(DARKGRAY);
        setlinestyle(SOLID_LINE, 1, 3);

        // Leg and body of stick man
        line(x + 40, y - 15, x + 40, y - 40);
        line(x + 40, y - 15, x + 45, y - 10);
        line(x + 45, y - 10, x + 45, y);
        line(x + 40, y - 15, x + 37, y);

        // Head and hand of stick man
        circle(x + 40, y - 45, 5);
        line(x + 40, y - 35, x + 50, y - 30);
        line(x + 40, y - 35, x + 35, y - 32);
        line(x + 35, y - 32, x + 45, y - 25);
        line(x + 60, y - 45, x + 27, y + 10);

        // Moving the position of
        // boat and stick man
        x++;

        setcolor(LIGHTBLUE);
        delay(250);

        // Clears the graphic device
        cleardevice();

        // Drawing sea/river
        setlinestyle(SOLID_LINE, 1, 1);
        setfillstyle(SOLID_FILL,
                    LIGHTBLUE);

        rectangle(0, getmaxy() / 2 + 150,
                getmaxx(), getmaxy());
        floodfill(getmaxx() - 10,
                getmaxy() - 10,
                LIGHTBLUE);

        // Rain drops
        setlinestyle(DASHED_LINE, 1, 2);
        x1 = 10, i = y1 = 0;
        x2 = 0, y2 = 70;

        while (i < 700) {
            line(x1, y1, x2, y2);
            x1 = x1 + 30;
            y2 = y2 + 60;
            i++;
        }

        // Drawing the boat
        setlinestyle(SOLID_LINE, 1, 1);
        setcolor(BROWN);
        setfillstyle(SOLID_FILL, BROWN);
        sector(x, y, 180, 360, 50, 10);

        // Body and leg of stic man
        setcolor(DARKGRAY);
        setlinestyle(SOLID_LINE, 1, 3);
        line(x + 40, y - 15, x + 40, y - 40);
        line(x + 40, y - 15, x + 45, y - 10);
        line(x + 45, y - 10, x + 45, y);
        line(x + 40, y - 15, x + 37, y);

        // Head hands of stick man
        circle(x + 40, y - 45, 5);
        line(x + 40, y - 35, x + 52, y - 30);
        line(x + 40, y - 35, x + 37, y - 32);
        line(x + 37, y - 32, x + 49, y - 25);
        line(x + 60, y - 45, x + 27, y + 10);

        // Forwarding the position of
        // the boat
        x++;

        // Sleep for 250 milliseconds
        delay(250);

        // Clears the graphic device
        cleardevice();
        j++;
    }

    getch();

    // Deallocate memory allocated
    // for graphic screen
    closegraph();

    return 0;
}
